function extractProfilePictures() {
    let profilePics = [];

    // Wait for all comments to load before extracting
    let commentsSection = document.querySelector("#comments");
    if (!commentsSection) {
        console.log("Comments not found!");
        return;
    }

    // Find all profile images in comments
    document.querySelectorAll("img").forEach(img => {
        if (img.src.includes("s88")) {  // Profile picture URLs contain 's88'
            profilePics.push(img.src);
        }
    });

    if (profilePics.length > 0) {
        console.log("Extracted Profile Pictures:", profilePics);
        chrome.runtime.sendMessage({ profilePics });
    } else {
        console.log("No profile pictures found!");
    }
}

// Ensure the script runs after a delay (to wait for comments to load)
setTimeout(extractProfilePictures, 3000);
