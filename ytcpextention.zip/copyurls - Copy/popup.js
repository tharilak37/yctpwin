document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("extractBtn").addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                files: ["content.js"]
            }).catch(error => console.log("Script Execution Failed:", error));
        });
    });
});
