chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.profilePics && message.profilePics.length > 0) {
        console.log("Saving Profile Pictures:", message.profilePics);

        const jsonData = JSON.stringify(
            message.profilePics.map(url => ({ link: url })),
            null,
            2
        );

        const blob = new Blob([jsonData], { type: "application/json" });
        const reader = new FileReader();

        reader.onloadend = function () {
            let base64data = reader.result.split(',')[1];

            chrome.downloads.download({
                url: "data:application/json;base64," + base64data,
                filename: "profile_pictures.json",
                saveAs: true
            });
        };

        reader.readAsDataURL(blob);
    } else {
        console.log("No profile pictures found or invalid data.");
    }
});
